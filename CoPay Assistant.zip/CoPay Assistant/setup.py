from distutils.core import setup
import py2exe

setup(
    windows = [
        {
            "script": 'CoPay Assistant.pyw',     
            "icon_resources": [(1, "favicon1.ico")]
        }
    ],
)



###windows was originally console, changed to attempt to hide the consol
